interface VolleyFileUploadRequest {
}