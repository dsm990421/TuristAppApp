package com.example.turistapp

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentProvider
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import org.json.JSONException
import org.json.JSONObject
import java.util.HashMap

class MainActivity : AppCompatActivity() {
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnEntrar: Button
    private lateinit var btnGoogle: Button
    private lateinit var btnFacebook: Button
    private lateinit var btnRegistro: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var callbackManager: CallbackManager
    private lateinit var requestQueue: RequestQueue
    private var httpURI="http://192.168.0.20:4500/usuarios/login"
    private lateinit var btnLoginN:Button

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sharedPreference =  getSharedPreferences("sesionesi", Context.MODE_PRIVATE)
        var negocios=sharedPreference.getBoolean("negocio",false)
            //Facebook
        if (negocios){
            var intent1: Intent = Intent(applicationContext,HomeNegocioActivity::class.java)
            startActivity(intent1)
            finish()
        }else{
        callbackManager = CallbackManager.Factory.create();
        //Volley
        requestQueue=Volley.newRequestQueue(this)
        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

            if(auth.currentUser!=null){
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }else{
                val gso= GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build()
                googleSignInClient= GoogleSignIn.getClient(this,gso)
                //Enlaces
                etEmail = findViewById<EditText>(R.id.etEmail)
                etPassword = findViewById<EditText>(R.id.etPassword)
                btnEntrar = findViewById<Button>(R.id.btnEntrar)
                btnGoogle = findViewById<Button>(R.id.btnGoogle)
                btnFacebook = findViewById<Button>(R.id.btnFacebook)
                btnRegistro = findViewById<Button>(R.id.btnRegistro)
                btnLoginN=findViewById(R.id.btnLoginN)
                googleSignInClient.signOut()
                FirebaseAuth.getInstance().signOut();
                LoginManager.getInstance().logOut();
                //Oyente
                btnRegistro.setOnClickListener {
                    val intent:Intent=Intent(this, RegistroActivity::class.java)
                    startActivity(intent)
                }
                btnGoogle.setOnClickListener { signInGoogle(); }
                btnEntrar.setOnClickListener { consultaUsuario() }
                btnFacebook.setOnClickListener { loginFacebook() }
                btnLoginN.setOnClickListener { IrAnegocio() }
            }
        }

    }

    private fun IrAnegocio(){
        var intent1: Intent = Intent(applicationContext,LoginNegocioActivity::class.java)
        startActivity(intent1)
        finish()
    }


    private fun loginFacebook(){
        LoginManager.getInstance().logInWithReadPermissions(this, listOf("email"))
        LoginManager.getInstance().registerCallback(callbackManager, object:
            FacebookCallback<LoginResult> {
            override fun onSuccess(result: LoginResult?) {
                result?.let {
                    val token=it.accessToken
                    val credential= FacebookAuthProvider.getCredential(token.token)
                    FirebaseAuth.getInstance().signInWithCredential(credential).addOnCompleteListener {
                        if (it.isSuccessful){
                            val sharedPreference =  getSharedPreferences("tipo_inicio",Context.MODE_PRIVATE)
                            var editor = sharedPreference.edit()
                            editor.putString("sesion","facebook")

                            editor.commit()
                            var intent1: Intent = Intent(applicationContext,HomeActivity::class.java)
                            startActivity(intent1)
                            finish()
                        }else{
                            Toast.makeText(applicationContext,"Error",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            override fun onCancel() {
            }
            override fun onError(error: FacebookException?) {
            }
        })
    }

    private fun consultaUsuario(){
        val email=etEmail.text.toString()
        val password=etPassword.text.toString()
        val jsonObject=JSONObject()
        jsonObject.put("email",email)
        jsonObject.put("password",password)
        val jsonObjectRequest=JsonObjectRequest(
            Request.Method.POST,httpURI,
            jsonObject,
            Response.Listener { response ->
                val id=response.get("id").toString()
                val nombre=response.get("nombre").toString()
                val email=response.get("email").toString()
                val sharedPreference2 =  getSharedPreferences("tipo_inicio",Context.MODE_PRIVATE)
                var editor2 = sharedPreference2.edit()
                editor2.putString("sesion","email")
                editor2.commit()
                val sharedPreference =  getSharedPreferences("datos_usuario",Context.MODE_PRIVATE)
                var editor = sharedPreference.edit()
                editor.putString("id",id)
                editor.putString("nombreu",nombre)
                editor.putString("email",email)
                editor.commit()
                IniciarSesion()
             }, Response.ErrorListener { error ->
                Toast.makeText(applicationContext,"Error al Autentificar",Toast.LENGTH_SHORT).show()
            });
        requestQueue.add(jsonObjectRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        callbackManager.onActivityResult(requestCode, resultCode, data)
        super.onActivityResult(requestCode, resultCode, data)
    }
    private fun signInGoogle(){
        val signInIntent=googleSignInClient.signInIntent
        launcher.launch(signInIntent)
    }
    private var launcher=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            result->
        if (result.resultCode== Activity.RESULT_OK){
            val task= GoogleSignIn.getSignedInAccountFromIntent(result.data)
            handleResults(task)
        }
    }
    private fun handleResults(task: Task<GoogleSignInAccount>) {
        if (task.isSuccessful){
            val account: GoogleSignInAccount?= task.result
            if (account!=null){
                updateUI(account)
            }
        }else{
            Toast.makeText(this, task.exception.toString(), Toast.LENGTH_LONG).show()
        }
    }

    private fun updateUI(account: GoogleSignInAccount) {
        val credential= GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential).addOnCompleteListener{
            if (it.isSuccessful){
                val sharedPreference =  getSharedPreferences("tipo_inicio",Context.MODE_PRIVATE)
                var editor = sharedPreference.edit()
                editor.putString("sesion","google")
                editor.commit()
                val intent:Intent=Intent(this, HomeActivity::class.java)
                startActivity(intent)
                finish()
            }else{
                Toast.makeText(this, it.exception.toString(), Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun IniciarSesion(){
        var email= etEmail.text.toString();
        var password = etPassword.text.toString();
        if(email.isEmpty()|| password.isEmpty()){
            Toast.makeText(baseContext, "Debe introducir todos los datos", Toast.LENGTH_SHORT).show()
        }else{
            FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(email,password)
                .addOnCompleteListener {
                    if(it.isSuccessful){
                        val sharedPreference2 =  getSharedPreferences("tipo_inicio",Context.MODE_PRIVATE)
                        var editor2 = sharedPreference2.edit()
                        editor2.putString("sesion","email")
                        editor2.commit()
                        var intent1: Intent = Intent(applicationContext,HomeActivity::class.java)
                        startActivity(intent1)
                        finish()
                    }
                    else Toast.makeText(this,"Error de Autentificacion",Toast.LENGTH_LONG).show()
                }

        }

    }




//    private fun savedata(email:String){
//        val intent1: Intent = Intent(this,HomeActivity::class.java).apply {
//            putExtra("email", email)
//        }
//        startActivity(intent1)
//    }
}