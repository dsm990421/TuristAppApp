package com.example.turistapp.data

data class Message(val message: String, val id: String, val time: String)